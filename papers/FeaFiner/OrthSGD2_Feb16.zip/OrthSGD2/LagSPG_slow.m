function [ Gf, sf, fo, funcVal ] = LagSPG( X,  y, XtX, Xty, G0, s0, K, Lambda, rho, rho_g, rho_s, tol, max_iter, verbose, debug)
%LAGBCD Solver to the Lagrange using SPG. 
%  min_{G,s} ||XGs - y||_2^2/n + rho_s * ||s||_1 + rho_g * ||G||_1 
%                - <Lambda, G' * G - I> + rho/2 ||G' * G - I||_F^2
%         s.t. G_{ij}>=0
%
%  NOTE: 1) this code is for STL only.
%        2) G0, s0 (d0) must be feasible at the very beginning.
%
%  Jiayu Zhou, 

warning('You are using a slow version of LagSPG'); %#ok

if nargin<15, debug = 0; end
stop_cond = 'tolerance reached';

% verbose = 1: only indicator, verbose >1: detailed iteration information.
if nargin<14, verbose = 1; end



% line search parameter
gamma = 1e-4; % sufficient decrease parameter. 
tilta = 0.5;  %G line search speed. 
ls_win = 10;   % non-monotone spectral length 

alpha_max  = 1e+0;
alpha_min  = 1e-15;

if isempty(Xty), Xty = X' * y; end

% used as error function.
err_func_init = @(x, g)    max(abs(proximal(x - g, rho_g, rho_s) - x)); 
err_func      = @(x, g, f) max(abs(proximal(x - g, rho_g, rho_s) - x))/ (abs(f) + 1);
n = length(y);
dim = size(X, 2);

% store variables in a single vector for easy computing.
G_s = 1;       G_e = dim * K;         % G: d by K
s_s = G_e + 1; s_e = G_e + K;         % s: K by 1

x = assemble_vars(G0, s0);
[funcVal, fv_ori, nspart, g] = eval_funv_grad(x);
err = err_func_init(x, g);

restarted = false;
%%% RESTART procedure to avoid init points that are too bad.
global f_init G_init s_init
if funcVal > 100 * f_init
    if verbose >1, disp('RESTART*****'); end
    restarted = true;
    x = assemble_vars(G_init, s_init);
    [funcVal, fv_ori, nspart, g] = eval_funv_grad(x);
    err = err_func_init(x, g);
end

iter_ind = {'/','-','\','|'};
if verbose == 1, fprintf('    '); end


alphas = 1/(err + eps);

iter = 1;
f_min = funcVal;
fo_min = fv_ori;
x_min = x;

while(err >= tol)
    if verbose == 1, fprintf('\b\b\b\b%4s', iter_ind{mod(iter, length(iter_ind))+1}); end
    
    if iter > max_iter, stop_cond = 'max iter reached';
        if verbose >1, disp(stop_cond);end; break; end

    f_start_idx = length(funcVal) - min(length(funcVal), ls_win) + 1;
%    rel_var_ls_win = var(funcVal(f_start_idx : end))/max(funcVal(end), 1);
%     if ls_win > 1 && iter > ls_win && rel_var_ls_win < tol
%         stop_cond = sprintf('var(funcval(ls_win)) tol reached [%.4f]\n', rel_var_ls_win);
%         if verbose >1, fprintf(stop_cond); end; break;
%     end;
    
    % backtrack line search.
    f_max = max(funcVal(f_start_idx : end));
    
    [x_new, fv_ori, f, nspart, g_new] = linesearch(x, f_max, nspart, g, alphas);
    funcVal = cat(1, funcVal, f);
    %disp(f);
    if f<f_min, f_min = f; x_min = x_new; fo_min = fv_ori; end;
    
    % compute inverse Rayleigh quatient. 
    x = x_new - x; g = g_new - g;
    xdotg = x' * g;
    xsqr  = x' * x;
    if xdotg <= 0
        alphas = alpha_max;
    else
        alphas = max(alpha_min, min(alpha_max, xsqr/xdotg));
    end
    
    % record information.
    x = x_new; g = g_new;
    iter = iter + 1;
    
    % computer error function for convergence.     
    err = err_func(x, g, f);
end

if verbose==1, fprintf('\b\b\b\b'); end
[Gf, sf] = dissemble_vars(x_min);
fo = fo_min;

% function values can be plotted. 
if debug > 0
    figure;
    plot(funcVal)
    min_idx = find(funcVal == min(funcVal));
    hold on;
    scatter(min_idx, funcVal(min_idx), 'rx', 'LineWidth', 12);
    if restarted, title(sprintf('restared: %s', stop_cond)); 
    else title(sprintf('%s', stop_cond)); end
end

    function [x_new, fv_ori_new, fv_aug_new, nspart_new, g_new] = ...
            linesearch(x, fv_aug_max, nspart, g, alphas)
        % Non-Monotone Linesearch Type I. 
        % NOTE: for sparse problems Type I is preferred. 
        %
        % x: search point. 
        % fv_aug_max: the maximum over last few iterations.
        % nspart: non-smooth part at x (l1 of s component). 
        % p: line search direction. 
        % alphas: inverse Rayleigh quatient.

        while true
            x_new = proximal(x - alphas * g, rho_g * alphas, rho_s * alphas); % proximal projection
            [fv_aug_new, fv_orils, nspart_new] = eval_funv_grad(x_new); %#ok
            delta = gamma * (x_new - x)' * g + nspart_new - nspart;
            %fprintf('line search alpha: %.4f, fv_aug %.4f, delta %.4f, fv_ori %.4f\n', ...
            %    alphas, fv_aug_new, delta, fv_orils)
            %delta = -gamma/2 * alphas * norm(x_new - x, 'fro');
            if fv_aug_new <= fv_aug_max + delta
                break;
            else
                alphas = alphas * tilta;
            end
        end
        [fv_aug_new, fv_ori_new, nspart_new, g_new] = eval_funv_grad(x_new);
    end

    function [fv_aug, fv_ori, nspart, grad] = eval_funv_grad(x)
        % fv_aug = function value augmented
        % fv_ori = function value original 
        % nspart = the value of non-smooth part i.e., rho_s ||s||_1 + rho_g ||G||_1
        % grad  = gradient. 
        [Gs, ss] = dissemble_vars(x);
        GsTGs  = Gs' * Gs;
        GsTGsE = GsTGs - eye(K);
        nspart = rho_s * sum(abs(ss)) + rho_g * sum(sum(abs(Gs)));
        XGsss = X * (Gs * ss);
        fv_ori = norm(XGsss - y, 'fro')^2/n + nspart;
        fv_aug = fv_ori - sum(sum(Lambda.*GsTGsE)) + rho/2 * norm(GsTGsE, 'fro')^2;
        
        if nargout >3  % computation of gradient is required. 
            gradG = 2 * (X' * XGsss) * ss' /n - 2 * Xty * ss'/n ...
                - Gs * (Lambda + Lambda') + 2 * rho * Gs * GsTGsE; 
            grads = 2 * Gs' * (X' * XGsss)/n - 2 * Gs' * Xty/n;
            
            grad = assemble_vars(gradG, grads);
        end
    end

    function [x] = assemble_vars(G, s)
        x = [G(:); s];
    end

    function [G, s] = dissemble_vars(x)
        G = reshape(x(G_s:G_e), [dim K]);
        s = reshape(x(s_s:s_e), [K   1]);
    end

    function x_pro = proximal(x, thr_g, thr_s)        
        [Gs, Ss] = dissemble_vars(x);
        Gzp = max(Gs - thr_g, 0);
        Szp = sign(Ss).*max(abs(Ss) - thr_s, 0);
        x_pro = assemble_vars(Gzp, Szp);
    end

end

