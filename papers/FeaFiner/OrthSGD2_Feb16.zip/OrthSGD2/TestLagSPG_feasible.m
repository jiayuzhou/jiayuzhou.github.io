clear; clc; close all;
rng('default'); rng(1985)
n   = 50;
dim = 100;
K   = 20;

%X = zscore(rand(n, dim));
%y = rand(n, 1);

rho_g = 0.01;
rho_s =0.05;

tol = 1e-6;
max_iter = 500;

[X, G_truth, s, y] = GenSynData(n, dim, K);

IDX = kmeans(X', K, 'EmptyAction', 'singleton');
G_kmeans = zeros(dim, K);
for j = 1:K
    idx = IDX == j;
    G_kmeans(idx, j) = 1;
end
G_kmeans = G_kmeans./repmat(sqrt(sum(G_kmeans.^2,1)), dim, 1);

G0 = G_kmeans;
s0 = s;

Lambda = ones(K, K); 
rho = 10;
tic;
[ Gf, sf, fv_ori, funcVal ] = ...
    LagSPG_slow( X,  y, [], [], G0, s0, K, Lambda, rho, rho_g, rho_s, tol, max_iter, 1, true);
toc;
%plot(funcVal)
err = norm(Gf'* Gf - eye(K),'fro')


tic;
[ Gf, sf, fv_ori, funcVal ] = ...
    LagSPG( X,  y, [], G0, s0, K, Lambda, rho, rho_g, rho_s, tol, max_iter,1,true);
toc;
%plot(funcVal)
err = norm(Gf'* Gf - eye(K),'fro')

