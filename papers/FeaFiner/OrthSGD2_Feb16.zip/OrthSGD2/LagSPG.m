function [ Gf, sf, fo, funcVal ] = LagSPG( X,  y, Xty, G0, s0, K, Lambda, rho, rho_g, rho_s, tol, max_iter, verbose, debug)
%LAGBCD Solver to the Lagrange using SPG. 
%  min_{G,s} ||XGs - y||_2^2/n + rho_s * ||s||_1 + rho_g * ||G||_1 
%                - <Lambda, G' * G - I> + rho/2 ||G' * G - I||_F^2
%         s.t. G_{ij}>=0
%
%  NOTE: 1) this code is for STL only.
%        2) G0, s0 (d0) must be feasible at the very beginning.
%
%  Jiayu Zhou, 

if nargin<14, debug = 0; end
stop_cond = 'tolerance reached';

% verbose = 1: only indicator, verbose >1: detailed iteration information.
if nargin<13, verbose = 1; end

% line search parameter
gamma = 1e-4; % sufficient decrease parameter. 
tilta = 0.5;  %G line search speed. 
ls_win = 10;   % non-monotone spectral length 

alpha_max  = 1e+0;
alpha_min  = 1e-15;

if isempty(Xty), Xty = X' * y; end

% used as error function.
n = length(y);

G = G0;
s = s0;
[funcVal, fv_ori, nspart, gG, gs] = eval_funv_grad(G, s);
err = err_func(G, s, gG, gs);

restarted = false;
%%% RESTART procedure to avoid init points that are too bad.
global f_init G_init s_init
if funcVal > 100 * f_init
    if verbose >1, disp('RESTART*****'); end
    restarted = true;
    G = G_init; s = s_init;
    [funcVal, fv_ori, nspart, gG, gs] = eval_funv_grad(G, s);
    err = err_func(G, s, gG, gs);
end

iter_ind = {'/','-','\','|'};
if verbose == 1, fprintf('    '); end


alphas = 1/(err + eps);

iter = 1;
f_min = funcVal;
fo_min = fv_ori;
G_min = G;
s_min = s;

while(err >= tol)
    if verbose == 1, fprintf('\b\b\b\b%4s', iter_ind{mod(iter, length(iter_ind))+1}); end
    
    if iter > max_iter, stop_cond = 'max iter reached';
        if verbose >1, disp(stop_cond);end; break; end

    f_start_idx = length(funcVal) - min(length(funcVal), ls_win) + 1;
    
    % backtrack line search.
    f_max = max(funcVal(f_start_idx : end));
    
    [G_new, s_new, fv_ori, f, nspart, gG_new, gs_new] ...
        = linesearch(G, s, f_max, nspart, gG, gs, alphas);
    funcVal = cat(1, funcVal, f);
    if f<f_min, f_min = f; G_min = G_new; s_min = s_new; fo_min = fv_ori; end;
    
    % compute inverse Rayleigh quatient. 
    G = G_new - G; gG = gG_new - gG; s = s_new - s; gs = gs_new - gs;
    xdotg = sum(sum(G.* gG)) + s' * gs; xsqr  = sum(sum(G.*  G)) + s' *  s; 
    if xdotg <= 0
        alphas = alpha_max;
    else
        alphas = max(alpha_min, min(alpha_max, xsqr/xdotg));
    end
    
    % record information.
    G = G_new; s = s_new; gG = gG_new; gs = gs_new;
    iter = iter + 1;
    
    % computer error function for convergence.     
    err = err_func(G, s, gG, gs, f);
end

if verbose==1, fprintf('\b\b\b\b'); end
Gf = G_min; sf = s_min;
fo = fo_min;

% function values can be plotted. 
if debug > 0
    figure;
    plot(funcVal)
    min_idx = find(funcVal == min(funcVal));
    hold on;
    scatter(min_idx, funcVal(min_idx), 'rx', 'LineWidth', 12);
    if restarted, title(sprintf('restared: %s', stop_cond)); 
    else title(sprintf('%s', stop_cond)); end
end

    function [G_new, s_new, fv_ori_new, fv_aug_new, nspart_new, gG_new, gs_new] = ...
            linesearch(G, s, fv_aug_max, nspart, gG, gs, alphas)
        % Non-Monotone Linesearch Type I. 
        % NOTE: for sparse problems Type I is preferred. 
        %
        % x: search point. 
        % fv_aug_max: the maximum over last few iterations.
        % nspart: non-smooth part at x (l1 of s component). 
        % p: line search direction. 
        % alphas: inverse Rayleigh quatient.

        while true
            [G_new s_new] = proximal(G - alphas * gG, s - alphas * gs, ... 
                rho_g * alphas, rho_s * alphas); % proximal projection
            [fv_aug_new, fv_orils, nspart_new] = eval_funv_grad(G_new, s_new); %#ok
            delta = gamma * sum(sum((G_new - G).* gG)) + gamma * (s_new - s)' * gs + nspart_new - nspart;
            if fv_aug_new <= fv_aug_max + delta
                break;
            else
                alphas = alphas * tilta;
            end
        end
        [fv_aug_new, fv_ori_new, nspart_new, gG_new, gs_new] = eval_funv_grad(G_new, s_new);
    end

    function [fv_aug, fv_ori, nspart, gradG, grads] = eval_funv_grad(Gs, ss)
        % fv_aug = function value augmented
        % fv_ori = function value original 
        % nspart = the value of non-smooth part i.e., rho_s ||s||_1 + rho_g ||G||_1
        % gradG  = gradient of G. 
        % gradG  = gradient of s. 
        GsTGs  = Gs' * Gs;
        GsTGsE = GsTGs - eye(K);
        nspart = rho_s * sum(abs(ss)) + rho_g * sum(sum(abs(Gs)));
        XGsss = X * (Gs * ss);
        fv_ori = norm(XGsss - y, 'fro')^2/n + nspart;
        fv_aug = fv_ori - sum(sum(Lambda.*GsTGsE)) + rho/2 * norm(GsTGsE, 'fro')^2;
        
        if nargout >3  % computation of gradient is required. 
            gradG = 2 * (X' * XGsss) * ss' /n - 2 * Xty * ss'/n ...
                - Gs * (Lambda + Lambda') + 2 * rho * Gs * GsTGsE; 
            grads = 2 * Gs' * (X' * XGsss)/n - 2 * Gs' * Xty/n;
        end
    end

    function [Gzp, Szp] = proximal(Gs, Ss, thr_g, thr_s)        
        Gzp = max(Gs - thr_g, 0);
        Szp = sign(Ss).*max(abs(Ss) - thr_s, 0);
    end

    function err = err_func(G, s, gG, gs, f)
        [Gp, sp] = proximal(G - gG, s- gs, rho_g, rho_s);
        err = max(max(max(abs(Gp - G))), max(abs(sp - s)));
        if nargin > 4
            err = err/ (abs(f) + 1);
        end
    end

end

