function [G, funcVal] = solveGcon(X, Y, S, rho_g, opts, XtTXt, XtTYt)
% Multi-Task Dictionary Learning with Least Squared Loss
% Part: Solve G (scaled, column-wise l1 constrained. no orthogonal)
% By Jiayu Zhou (jiayu.zhou@asu.edu)
% Dec 5 2012
%
%%% Objective:
%   G^* =  argmin_G 1/T \sum_{t=1}^T 1/n_t (Xt G S_t - yt)_2^2}
%   subject to: G_{i,j} \forall i,j \geq 0
%               \|G * e_i\|_1 \leq rho_g
%
%   In the projection the constraint for each column is decoupled.
%
%%% INPUT
% X: {d * n_t} * T - input matrix
% Y: {n_t * 1} * T - output matrix
% S: coefficient K * T (K: dictionary size)
% rho_G: Ecliean radius for columns of G.
% opts: optional
%
% XtTXt: XtTXt{t} = Xt' * Xt
% XtTYt: XtTYt{t} = Xt' * Yt
% StStT: StStT{t} = St * St'
%
%%% OUTPUT
% G: model d * K
% funcVal: function value vector.

T = length(X);
d = size(X{1}, 2);
K = size(S, 1);
funcVal = [];

if rho_g <= 0
    error('rho_g shoulde be a positive number')
end

% initial guess for Euclidean projection
lambda0 = zeros(K, 1);

if nargin < 5
    opts = [];
end

if nargin < 7
    % compute cached.
    XtTXt = cell(T, 1);
    XtTYt = cell(T, 1);
    for t = 1: T
        XtTXt{t} = X{t}' * X{t};
        XtTYt{t} = X{t}' * Y{t};
    end
end

StStT = cell(T, 1);
for t = 1: T
    StStT{t} = S(:, t) * S(:, t)';
end

if ~isfield(opts, 'maxIter')
    opts.maxIter = 500;
end

if ~isfield(opts, 'tol')
    opts.tol = 10^-5;
end

opts.tFlag = 1;

% init point
if isfield(opts, 'start_point')
    G0 = opts.start_point;
else
    G0 = rand(d, K);
end

% the initial point should satisify the constraints.
% see analysis below.
G0 = setInitConstraint(G0);

Gz     = G0;
Gz_old = G0;

t     = 1;
t_old = 0;

iter = 0;
gamma = 1; % init step size.
gamma_inc = 2;

while iter < opts.maxIter
    alpha = (t_old - 1)/t;
    
    Gs = (1+alpha) * Gz - alpha * Gz_old;
    [Fs gGs] = gradVal_eval(Gs);
    
    while true % line search
        Gzp = proximal_G (Gs - gGs/gamma, rho_g);
        Fzp = gradVal_eval(Gzp);
        
        delta_Gzp = Gzp - Gs;
        
        Fzp_gamma = Fs + trace(delta_Gzp' * gGs) ...
            + gamma/2 * norm(delta_Gzp, 'fro')^2;
        
        if Fzp <= Fzp_gamma
            break;
        else
            gamma = gamma * gamma_inc;
        end
    end
    
    Gz_old = Gz;
    Gz = Gzp;
    
    funcVal = cat(1, funcVal, Fzp);
    % in the constrained problem there is no
    % non-smooth terms in the function value.
    
    % stop condition.
    switch(opts.tFlag)
        case 0
            if iter>=2
                if (abs( funcVal(end) - funcVal(end-1) ) <= opts.tol)
                    break;
                end
            end
        case 1
            if iter>=2
                if (abs( funcVal(end) - funcVal(end-1) ) <=...
                        opts.tol* funcVal(end-1))
                    break;
                end
            end
        case 2
            if ( funcVal(end)<= opts.tol)
                break;
            end
        case 3
            if iter>=opts.maxIter
                break;
            end
    end
    
    iter = iter + 1;
    t_old = t;
    t = 0.5 * (1+(1+4 * t^2)^0.5);
end

G = Gzp;

    function G0 = setInitConstraint(G0)
        % we require that the inital point should satisfy the constraint.
        % nonnegative
        G0(G0<0) = 0;
        % set l1 length
        col_sum = sum(G0, 1);
        for tt = 1: K
            if col_sum(tt) > 0
                G0(:, tt) = G0(:, tt) / col_sum(tt);
            else
                G0(1, tt) = rho_g; % set random to rho_o;
            end
        end
    end

    function [Fs gGs] = gradVal_eval(Gs)
        if nargout >1
            % compute function value and gradient
            Fs = 0;
            gGs = zeros(size(Gs));
            for tt = 1: T
                %-- Is it possible to improve?
                comp_grad = 2 * XtTXt{tt} * Gs * StStT{tt} - XtTYt{tt} * S(:, tt)';
                %--
                gGs = gGs + comp_grad/length(Y{tt});
                comp_funv = norm(X{tt} * Gs * S(:, tt) - Y{tt}, 'fro')^2;
                Fs  = Fs  + comp_funv/length(Y{tt});
            end
            gGs = gGs./T;
            Fs  = Fs./T;
        else
            % only compute function value
            Fs = 0;
            for tt = 1: T
                comp_funv = norm(X{tt} * Gs * S(:, tt) - Y{tt}, 'fro')^2;
                Fs  = Fs  + comp_funv/length(Y{tt});
            end
            Fs  = Fs./T;
        end
    end

    function Gzp = proximal_G (Gsp, thr)
        % non-negative l1 norm projection.
        % columns of Gsp are projected non-negative to \|Gsp * e_i\| <= thr
        Gzp = zeros(size(Gsp));
        for cc = 1:K
            gvect = Gsp(:, cc);
            g_idx = gvect >= 0; % only compute projection for nnz elements.
            % negative elements are directly set to 0.
            if nnz(g_idx) ==0
                continue;
            end
            gvect = gvect(g_idx);
            [Gzp(g_idx, cc), lambda0(cc), ~] = eplb(gvect, length(gvect), thr, lambda0(cc));
        end
    end

end



