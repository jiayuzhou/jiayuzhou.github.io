function [s, funcVal] = solveS(X, y, G, rho_s, s0, maxIter, tol, XtX, Xty)
% Single task dictionary Learning with Least Squared Loss
% Part: Solve S
% By Jiayu Zhou (jiayu.zhou@asu.edu)
%
%%% Objective:
%   argmin_s  1/n (X G s - y)_2^2} + rho_s \|s\|_1
%
%%% INPUT
% X: n * d - input matrix
% Y: n * 1 - output matrix
% G: dictionary d * K (K: dictionary size)
% rho_s: sparsity of S.
%
% XtX = X' * X
% Xty = X' * y
%
%%% OUTPUT
% s: model d * 1
% funcVal: function value vector.

n = length(y);
funcVal = [];
tFlag = 1;

% init point
sz     = s0;
Sz_old = s0;

t     = 1;
t_old = 0;

iter = 0;
gamma = 1; % init step size.
gamma_inc = 2;

while iter < maxIter
    alpha = (t_old - 1)/t;
    
    ss = (1+alpha) * sz - alpha * Sz_old;
    [Fs gSs] = gradVal_eval(ss);
    
    while true % line search
        szp = proximal_S(ss - gSs/gamma, rho_s/gamma);
        Fzp = gradVal_eval(szp);
        
        delta_Szp = szp - ss;
        Fzp_gamma = Fs + sum(sum(delta_Szp .* gSs)) ...
            + gamma/2 * norm(delta_Szp, 'fro')^2;
        
        if Fzp <= Fzp_gamma
            break;
        else
            gamma = gamma * gamma_inc;
        end
    end
    
    Sz_old = sz;
    sz = szp;
    
    funcVal = cat(1, funcVal, Fzp + nonsmooth_eval(sz, rho_s));
    
    % stop condition.
    switch(tFlag)
        case 0
            if iter>=2
                if (abs( funcVal(end) - funcVal(end-1) ) <= tol)
                    break;
                end
            end
        case 1
            if iter>=2
                if (abs( funcVal(end) - funcVal(end-1) ) <=...
                        tol* funcVal(end-1))
                    break;
                end
            end
        case 2
            if ( funcVal(end)<= tol)
                break;
            end
        case 3
            if iter>=maxIter
                break;
            end
    end
    
    iter = iter + 1;
    t_old = t;
    t = 0.5 * (1+(1+4 * t^2)^0.5);
end

s = szp;

    function [Fs gSs] = gradVal_eval(ss)
        if nargout >1
            % compute function value and gradient
            gSs = 2 * G' * (XtX * (G * ss))/n - 2 * G' * Xty /n;
            Fs = norm(X * (G * ss) - y, 'fro')^2/n;
            
        else
            Fs = norm(X * (G * ss) - y, 'fro')^2/n;
        end
    end

    function szp = proximal_S (ssp, thr)
        % non-negative l1 norm projection.
        szp = sign(ssp).*max(abs(ssp) - thr, 0);
    end

    function ne = nonsmooth_eval(sz, rho_s)
        % non smooth part evaluation.
        ne = rho_s * sum(abs(sz(:)));
    end
end


