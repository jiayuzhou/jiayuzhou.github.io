function [A, G, x, y] = GenSynData(n, p, k)
% y = A  * G * x;
% A: n by p
% G: p by k
% x: k by 1
% 
% clear, clc;
% n = 20;
% p = 50;
% k = 3;
ratio = 0.5;        % ratio of x to be zero

% ratio = 0.1;
% A = zeros(n, p);
% 
% nBottom = round(ratio * n);
% A(end-nBottom+1:end, :) = randn(nBottom, p);
% 
% nRows = n - nBottom;
% nRowsB = round(nRows / k);
% nColsB = round(p / k);
% 
% for i = 1:k
%     ind_Row_start = (i - 1) * nRowsB + 1;
%     ind_Col_start = (i - 1) * nColsB + 1;
%     if i == k
%         ind_Row_end = n - nBottom;
%         ind_Col_end = p;
%     else
%         ind_Row_end = i * nRowsB;
%         ind_Col_end = i * nColsB;
%     end
%     A(ind_Row_start:ind_Row_end, ind_Col_start:ind_Col_end) = ...
%         randn(ind_Row_end - ind_Row_start + 1, ind_Col_end - ind_Col_start + 1);
% end

nColsB = round(p / k);
% Generate the block diag matrix for covariance.

Sigma = zeros(p);
G = zeros(p, k);

for i = 1:k
    ind_start = (i - 1) * nColsB + 1;
    if i == k
        ind_end = p;
    else
        ind_end = i * nColsB;
    end
    p0 = ind_end - ind_start + 1;
    
    Sigma0 = eye(p0);
    Sigma0(Sigma0 == 0) = 0.9;
    
    Sigma(ind_start:ind_end, ind_start:ind_end) = Sigma0;
    
    G0 = rand(p0, 1);
    G(ind_start:ind_end, i) = G0 / sum(G0);
end

A = mvnrnd(zeros(1, p), Sigma, n) + 1e-3 * randn(n, p);

x = randn(k, 1);
n_zero = round(k * ratio);
zero_ind = randperm(k);
zero_ind = zero_ind(1:n_zero);

x(zero_ind) = 0;

y = A * G * x;