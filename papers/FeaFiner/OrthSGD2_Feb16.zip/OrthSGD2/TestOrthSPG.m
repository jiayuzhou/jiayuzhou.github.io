% MacBookPro.
% rng('default'); rng(1985)
% n   = 50;
% dim = 100;
% K   = 40;
%------
% function value 3.355, nrmVar 0.2762, residual error 1.002, fv diff 238.4281, rho 1.0000, nrmLambda 40.0000 
% function value 1.824, nrmVar 0.1585, residual error 0.201, fv diff 87.7152, rho 5.0000, nrmLambda 40.0000 
% function value 1.264, nrmVar 0.1284, residual error 0.04012, fv diff 25.3193, rho 25.0000, nrmLambda 40.0000 
% function value 1.047, nrmVar 0.0497, residual error 0.007996, fv diff 6.1114, rho 125.0000, nrmLambda 40.0000 
% function value 0.9877, nrmVar 0.0105, residual error 0.001596, fv diff 1.2799, rho 625.0000, nrmLambda 40.0000 
% function value 0.9741, nrmVar 0.0026, residual error 0.0003197, fv diff 0.2560, rho 3125.0000, nrmLambda 40.0000 
% function value 0.9713, nrmVar 0.0012, residual error 6.384e-05, fv diff 0.0512, rho 15625.0000, nrmLambda 40.0000 
% function value 0.9707, nrmVar 0.0003, residual error 1.277e-05, fv diff 0.0102, rho 78125.0000, nrmLambda 40.0000 
% function value 0.9706, nrmVar 0.0000, residual error 2.558e-06, fv diff 0.0020, rho 390625.0000, nrmLambda 40.0000 
% function value 0.9706, nrmVar 0.0000, residual error 5.107e-07, fv diff 0.0004, rho 1953125.0000, nrmLambda 40.0000 
% function value 0.9706, nrmVar 0.0000, residual error 1.021e-07, fv diff 0.0001, rho 9765625.0000, nrmLambda 40.0000 
% Orthogonal Group Learning terminates at 10 iterations. 
% Elapsed time is 18.320314 seconds.
%    8.1916e-05
% 
% {||Ge_i||_1}_inf 2.2360 
% s sparsity 0.4500 
% G sparsity 0.6880 

clear; clc; close all;
rng('default'); rng(1985)
n   = 50;
dim = 100;
K   = 40;

X = zscore(rand(n, dim));
y = rand(n, 1);

con_g = 0.01;
rho_s =0.05;

opts.tol = 1e-6;
opts.max_iter = 500;


tic;
opts.verbose_OrthSPG = 2;
[ G, s, fv_diff ] = OrthSPG( X, y, K, con_g, rho_s, opts);
toc;

disp(fv_diff);
fprintf('{||Ge_i||_1}_inf %.4f \n', max(sum(G, 1)));
fprintf('s sparsity %.4f \n', sum(s == 0)/ numel(s));
fprintf('G sparsity %.4f \n', nnz(G == 0)/ numel(G));
