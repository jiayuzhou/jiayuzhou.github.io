function [ G, s ] = GenLearn( X, y, K, rho_g, rho_s, opts )
%GENLEARN Summary of this function goes here
%   Detailed explanation goes here

%% Initialize algorithm.
if nargin<5, opts = []; end

% This controls the details of output information on console. 
verbose_OrthSPG    = 1;     % orthogonal grouping algorithm output info (out-loop). 
if isfield(opts, 'verbose_OrthSPG'),     verbose_OrthSPG = opts.verbose_OrthSPG;        end
verbose_SPG_solver = 1;     % non-monotone SPG solver output info (inner-loop) 
if isfield(opts, 'verbose_SPG_solver'),  verbose_SPG_solver = opts.verbose_SPG_solver;  end
showSPGFigures     = false; % non-monotone SPG solver convergence figures. 
if isfield(opts, 'showSPGFigures'),      showSPGFigures = opts.showSPGFigures;          end

clean_thr = 1e-4;           % values of G below this threshold will be removed during post-processing. 
post_processing = true;     % use post-processig to clean up the group assignment
                            % the original may not look good because of orth
                            % constraint. 
if isfield(opts, 'clean_thr'),       clean_thr = opts.clean_thr;             end
if isfield(opts, 'post_processing'), post_processing = opts.post_processing; end
                           
repeat_orth_learn = 0;      % how many times we repeat the OrthSPG algorithm 
                            % to refine the solution. 
if isfield(opts, 'repeat_orth_learn'), repeat_orth_learn = opts.repeat_orth_learn; end
                           
rFlag = 1;                  % if the penalty is relative. 
if isfield(opts, 'rFlag'), rFlag = opts.rFlag; end

eps_E = 1e-3;               % equality feasibility
if isfield(opts, 'eps_E'), eps_E = opts.eps_E; end
eps_O = 1e-3;               % objective and augmented consistency.
if isfield(opts, 'eps_O'), eps_O = opts.eps_O; end

XtX = X' * X; Xty = X' * y; n = length(y); dim = size(X, 2);

% normalization function that normalizes the length of each column to be zero.                            
column_normalize = @(Gi) Gi./repmat(sqrt(sum(Gi.^2,1)), dim, 1);
                           
use_kmeans_init = true;
if isfield(opts, 'use_kmeans_init'), use_kmeans_init = opts.use_kmeans_init; end



% starting points.
if isfield(opts, 'start_point_G'), G0 = opts.start_point_G;
else
    if use_kmeans_init  % k-means intial point. 
        IDX = kmeans(X', K, 'EmptyAction', 'singleton');
        G_kmeans = zeros(size(X, 2), K);
        for j = 1:K
            idx = IDX == j;
            G_kmeans(idx, j) = 1;
        end
    else % random group assignment as inital point. 
        assign = ceil(rand(dim, 1) * K);
        G0 = zeros(dim, K);
        for dd = 1: dim, G0(dd, int32(assign(dd))) = 1; end
    end
    G0 = column_normalize(G0); %G0./repmat(sqrt(sum(G0.^2,1)), dim, 1);
end

if isfield(opts, 'start_point_s'), s0 = opts.start_point_s;
else s0 = rand(K, 1); end
eval_model (G0, s0, 'Initial');


% Compute relative penalty parameter using the intial soloution. 
if rFlag == 1
    rho_g = min(1, max(0, rho_g));
    rho_g_max = max(max(abs(2 * Xty * s0' /n)));
    rho_g     = rho_g * rho_g_max;
    
    rho_s     = min(1, max(0, rho_s));
    rho_s_max = max(abs(2 * G0' * Xty /n));
    rho_s     = rho_s * rho_s_max;
end

% prepare solver options.
orth_opts = [];
orth_opts.standalone_mode = false;
orth_opts.XtX = XtX; 
orth_opts.Xty = Xty; 
orth_opts.verbose_SPG_solver = verbose_SPG_solver;
orth_opts.verbose_OrthSPG    = verbose_OrthSPG;
orth_opts.showSPGFigures     = showSPGFigures;
orth_opts.eps_E = eps_E;
orth_opts.eps_O = eps_O;

%% preprocessing by one step alternating. 
G1 = G0;
[s1 fv1] = solveS(X, y, G0, 0, s0, 500, 1e-5, XtX, Xty); %#ok
eval_model (G0, s1, 'Preprocessing');

% augmented lagrange 
orth_opts.start_point_G = G1;
orth_opts.start_point_s = s1;
[ G2, s2 ] = OrthSPG( X, y, K, rho_g, rho_s, orth_opts);
eval_model (G2, s2, 'AugLag0');

% postprocessing;
G3 = G2;
if post_processing
    G3(G3<clean_thr) = 0; G3 = column_normalize(G3);
    s3 = solveS(X, y, G3, rho_s, s2, 500, 1e-5, XtX, Xty);
    ov3 = eval_model (G3, s3, 'PostPocessing0');
else
    s3 = s2;
    ov3 = eval_model (G3, s3, 'PostPocessing0', false);
end

G = G3; s = s3; ov = ov3;

%% repeat the algorithm to refine the solution. 
G_rep_init = G3;
s_rep_init = s3; 
for rep = 1: repeat_orth_learn
    % augmented lagrange rep. 
    orth_opts.start_point_G = G_rep_init;
    orth_opts.start_point_s = s_rep_init;
    [ G_rep, s_rep ] = OrthSPG( X, y, K, rho_g, rho_s, orth_opts);
    eval_model (G_rep, s_rep, sprintf('AugLag-%u', rep));

    % postprocessing rep;
    G_rep_init = G_rep;
    if post_processing        
        G_rep_init(G_rep_init<clean_thr) = 0; G_rep_init = column_normalize(G_rep_init);
        s_rep_init = solveS(X, y, G_rep_init, rho_s, s_rep, 500, 1e-5, XtX, Xty);
        ov_repcl = eval_model (G_rep_init, s_rep_init, sprintf('PostPocessing-%u', rep));
    else
        s_rep_init = s_rep;
        ov_repcl = eval_model (G_rep_init, s_rep_init, sprintf('PostPocessing-%u', rep), false);
    end
    
    % record the optimal performance
    if ov_repcl < ov, G = G_rep_init; s = s_rep_init; ov = ov_repcl;
    else break; end % if no further improvement stop. 
end

fprintf('Done. Final funcVal %.4f\n', ov);

    function [obj_val, loss] = eval_model (G, s, str, display)
        if nargin<4, display = true; end
        % evaluate the loss and the entire formulation (with nonsmooth terms)
        loss = norm(X* (G* s) - y, 'fro')^2/n;
        obj_val = loss + rho_g * sum(sum(abs(G))) + rho_s * sum(abs(s));
        
        if display
            sparsity_g = nnz(G)/numel(G);
            sparsity_s = nnz(s)/numel(s);
            
            if nargin<3
                fprintf(     'Loss; %.4f, Formulation with penalty: %.4f, Density G: %.4f, Density S: %.4f\n',...
                    loss, obj_val, sparsity_g, sparsity_s);
            else
                fprintf('[%s] Loss; %.4f, Formulation with penalty: %.4f, Density G: %.4f, Density S: %.4f\n',...
                    str, loss, obj_val, sparsity_g, sparsity_s);
            end
        end
    end
end

