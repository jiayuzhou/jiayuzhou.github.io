function [ G_min, s_min, fv_diff_min] = OrthSPG( X, y, K, rho_g, rho_s, opts)
%ORTHSPG The Orth-Group learning Lasso via spectral projected gradient (SPG).
%        The single task learning. 
%   
%%% Objective:
%   argmin_{G, S} 1/T \sum_{t=1}^T 1/n_t (Xt G S_t - yt)_2^2}
%            + rho_s||S||_1 + rho_g ||G||_1  (sparsity on coefficient)
%   subject to: G_{i,j} \forall i,j \geq 0   (non-negativity dictionary)
%               G^T G = I                    (orthogonality on groups)
%
%%% INPUT
% X:     n * d - input matrix
% Y:     n * 1 - output matrix
% K:     dictionary size.
% rho_s: sparsity of S.
% con_g: sparsity/length of columns of G.
% opts:  optional parameters
%
% Jiayu Zhou Feb 12, 2013. 
%
if nargin<6,  opts = [];  end
resd_func = @(G)  G' * G - eye(K);       % function of computing residual using G.
infy_norm = @(res) max(max(abs(res)));  % function of computing feasibility using residual

n   = size(X, 1); % sample size;
dim = size(X, 2); % feature dimensionality 

eta    = 0.25; % the ratio of equality feasibility to change Lambda
gammaE = 5;    % incremental of rho;
eps_E  = 1e-3; % accuracy for equality constraints.
if isfield(opts, 'eps_E'), eps_E = opts.eps_E; end
eps_O  = 1e-3; % accuracy for objective function value.
if isfield(opts, 'eps_O'), eps_O = opts.eps_O; end
rhoE    = 1;    % init penalty
rhoE_max = 1e10;
LambdaE = ones(K, K); % NOTE: try use ones(K, K)-eye(K).

standalone_mode = true; % by default we assume no outer loops are there. 
if isfield(opts, 'standalone_mode'), standalone_mode = opts.standalone_mode; end

use_kmeans_G_init   = true; % use k-means result as the init point.
if isfield(opts, 'use_kmeans_G_init'), use_kmeans_G_init = opts.use_kmeans_G_init; end

% debug information. 
showSPGFigures = false; % if turned on then SPG solver will output convergence 
if isfield(opts, 'showSPGFigures'),     showSPGFigures = opts.showSPGFigures;         end
verbose_SPG_solver = 1; % 1: indicator, 2: detailed convergence information.
if isfield(opts, 'verbose_SPG_solver'), verbose_SPG_solver = opts.verbose_SPG_solver; end
verbose_OrthSPG = 1;    % 1: indicator, 2: detailed convergence informatino. 
if isfield(opts, 'verbose_OrthSPG'),    verbose_OrthSPG    = opts.verbose_OrthSPG;    end


if standalone_mode
    XtX = X' * X; Xty = X' * y; 
    
    % If this option is turned on then we use current point
    % to refine a better start_point.
    refine_start_points = true;
    
    % starting points.
    if isfield(opts, 'start_point_G'), G = opts.start_point_G; refine_start_points = true;
    else
        if use_kmeans_G_init
            IDX = kmeans(X', K, 'EmptyAction', 'singleton');
            G = zeros(dim, K);
            for j = 1:K
                idx = IDX == j;
                G(idx, j) = 1;
            end
        else
            % random assign to groups.
            assign = ceil(rand(dim, 1) * K);
            G = zeros(dim, K);
            for dd = 1: dim, G(dd, int32(assign(dd))) = 1; end
        end
        G = G./repmat(sqrt(sum(G.^2,1)), dim, 1); % normalize to identity
    end
    if isfield(opts, 'start_point_s'), s = opts.start_point_s;
    else s = rand(K, 1); end
    if refine_start_points
        s = solveS(X, y, G, rho_s, s, 500, 1e-5, XtX, Xty);
    end
else
    % in nested mode, G and s must given. 
    G = opts.start_point_G; 
    s = opts.start_point_s;
    %XtX = opts.XtX; 
    Xty = opts.Xty; 
end



% used for RESTART in subroutine. 
global G_init s_init f_init
G_init = G;
s_init = s;
funcVal = norm(X * (G * s) - y, 'fro')^2/n + rho_s * sum(abs(s)) + rho_g * sum(sum(abs(G)));
f_init = funcVal;


errE_old = infy_norm(resd_func(G));
if errE_old <= eps_E
    errE_old = 10 * errE_old;
end

max_iter = 500; % initial max iteration
max_iter_fine = max_iter * 3;
tol  = 1e-4;
if isfield(opts, 'max_iter'), max_iter = opts.max_iter; end 
if isfield(opts, 'tol'),      tol      = opts.tol;      end 

flag = 0;

%% initialization
if verbose_OrthSPG == 1; fprintf('Iteration:     '); end

iter = 0; 

fv_diff_min = inf; G_min = G; s_min = s;

while iter < 100 % maximum outer iteration.
    [ Gn, sn, fv_ori, fv_aug_arr] = LagSPG( X, y, Xty, G, s, K, LambdaE, rhoE, rho_g, rho_s, tol, max_iter, verbose_SPG_solver, showSPGFigures);
    if nnz(Gn) == 0, disp('Null model G found.'); break; end
    if nnz(sn) == 0, disp('Null model s found.'); break; end
    funcVal = cat(1, funcVal, fv_ori);
    
    fv_aug = fv_aug_arr(end);
    % increase precision for later iterations. 
    if iter >= 5, max_iter = max_iter_fine; end
    
    resE = resd_func(Gn);
    errE = infy_norm(resE);   % feasibility using infty norm. 
    
    nrmVar = max(infy_norm(Gn - G), infy_norm(sn - s));
    fv_diff = abs(fv_aug - fv_ori)/ max(abs(fv_ori), 1);
    
    if fv_diff < fv_diff_min
        % we record the minimum fv_diff to return. 
        % this prevents the possible diverge due to numerical issues. 
        fv_diff_min = fv_diff; G_min = Gn; s_min = sn;
    end
    
    if verbose_OrthSPG>1
        fprintf('function value %.4g, nrmVar %.4f, residual error %.4g, fv diff %.4f, rho %.4f, nrmLambda %.4f \n', fv_ori, nrmVar, errE, fv_diff, rhoE, norm(LambdaE, 'fro'));
    end
    
    if errE <= eps_E && abs(fv_aug - fv_ori)/ max(abs(fv_ori), 1) <= eps_O
        if flag
            break; 
        else
            max_iter = max_iter_fine; flag = 1;
        end
    end
    
    if errE < eta * errE_old
        LambdaE = LambdaE + rhoE * resE;
        errE_old = errE;
    else
        %rhoE = max(rhoE * gammaE, norm(LambdaE, 'fro')^1.2);
        rhoE = min(rhoE * gammaE, rhoE_max);
    end
    
    G = Gn; s = sn;
    iter = iter + 1; 
    
    if verbose_OrthSPG == 1; fprintf('\b\b\b\b\b%5i',iter); end
    
end

if verbose_OrthSPG>0
    fprintf('Orthogonal Group Learning terminates at %u iterations. \n', iter);
end

end

