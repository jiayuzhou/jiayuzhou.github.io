% Result on my MacBook Pro. 17. 
% [Initial] Loss; 41.7786, Formulation with penalty: 42.8077, Density G: 0.0500, Density S: 1.0000
% [Preprocessing] Loss; 1.8596, Formulation with penalty: 4.0948, Density G: 0.0500, Density S: 1.0000
% function value 2.375, nrmVar 0.7120, residual error 1.082, fv diff 84.1981, rho 1.0000, nrmLambda 20.0000 
% function value 1.806, nrmVar 0.9160, residual error 0.2175, fv diff 22.1460, rho 5.0000, nrmLambda 20.0000 
% function value 1.459, nrmVar 0.4724, residual error 0.04269, fv diff 5.4813, rho 25.0000, nrmLambda 20.0000 
% function value 1.289, nrmVar 0.1785, residual error 0.008773, fv diff 1.2407, rho 125.0000, nrmLambda 20.0000 
% function value 1.253, nrmVar 0.0399, residual error 0.001808, fv diff 0.2552, rho 625.0000, nrmLambda 20.0000 
% function value 1.246, nrmVar 0.0065, residual error 0.0003659, fv diff 0.0513, rho 3125.0000, nrmLambda 20.0000 
% function value 1.244, nrmVar 0.0073, residual error 7.336e-05, fv diff 0.0103, rho 15625.0000, nrmLambda 20.0000 
% function value 1.244, nrmVar 0.0016, residual error 1.468e-05, fv diff 0.0021, rho 78125.0000, nrmLambda 20.0000 
% function value 1.244, nrmVar 0.0002, residual error 2.937e-06, fv diff 0.0004, rho 390625.0000, nrmLambda 20.0000 
% function value 1.244, nrmVar 0.0001, residual error 5.875e-07, fv diff 0.0001, rho 1953125.0000, nrmLambda 20.0000 
% Orthogonal Group Learning terminates at 9 iterations. 
% [AugLag0] Loss; 0.0377, Formulation with penalty: 1.2436, Density G: 0.1775, Density S: 0.1000
% [PostPocessing0] Loss; 0.0377, Formulation with penalty: 1.2436, Density G: 0.0295, Density S: 0.1000
% Done. Final funcVal 1.2436
% {||Ge_i||_1}_inf 3.9281 
% s sparsity 0.9000 
% G sparsity 0.9705 



clear; clc; close all;
rng('default'); rng(1985)
n   = 50;
dim = 100;
K   = 20;

%X = zscore(rand(n, dim));
%y = rand(n, 1);

rho_g = 0.01;
%rho_s =0.1;
rho_s =0.05;

opts.tol = 1e-6;
opts.max_iter = 500;

[X, G_truth, s, y] = GenSynData(n, dim, K); %#ok

IDX = kmeans(X', K, 'EmptyAction', 'singleton');
G_kmeans = zeros(dim, K);
for j = 1:K
    idx = IDX == j;
    G_kmeans(idx, j) = 1;
end
G_kmeans = G_kmeans./repmat(sqrt(sum(G_kmeans.^2,1)), dim, 1);

opts.start_point_G = G_kmeans;
opts.post_processing = true;
opts.repeat_orth_learn = 0;
opts.eps_O = 1e-3;
opts.verbose_OrthSPG = 2; % output outerloop debug information. 
[ G, s ] = GenLearn( X, y, K, rho_g, rho_s, opts );


fprintf('{||Ge_i||_1}_inf %.4f \n', max(sum(G, 1)));
fprintf('s sparsity %.4f \n', sum(s == 0)/ numel(s));
fprintf('G sparsity %.4f \n', nnz(G == 0)/ numel(G));
